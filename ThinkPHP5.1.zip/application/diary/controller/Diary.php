<?php
namespace app\diary\controller;

class Diary
{
    public function index()
    {
        return '你开心么?hehe';
    }

}
