<?php
namespace app\diary\controller;

class Index
{
    public function index()
    {
        return ' 你开心么?<br>yes 很开心 ' ;
    }

}
